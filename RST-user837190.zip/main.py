"""
Name: Emma Boutoille 
Date: January 12 
Side Scroller RST  

""" 
# ----------------------------------- Imports -----------------------------------------
import turtle # import turtle library
import random # import random library 
import time # import time library

# ----------------------------------- Window Setup ----------------------------------------- 
wn = turtle.Screen() # create a window called wn 
wn.setup(width = 1300, height = 975) # setup a window with width and height 
wn.title("RST - Side Scroller - T-Rex Run") # set the window title 
wn.register_shape("desert_bg.gif") # register the first desert background image
wn.register_shape("desert_bg2.gif") # register the second desert background image
wn.register_shape("home_screen.gif") # register home screen image
wn.register_shape("play_button.gif") # regitser play button shape
wn.register_shape("exit_button.gif") # register exit button shape
wn.register_shape("continue_button.gif") # register continue button shape
wn.register_shape("cactus.gif") # register cactus image
wn.register_shape("pterodactyl.gif") # register pterodactyl image
wn.register_shape("heart.gif") # register heart image for the lives
wn.register_shape("t-rex.gif") # register t-rex image for the t-rex turtle
wn.register_shape("knocked_cactus.gif") # register knocked down cactus image
wn.register_shape("error_message.gif") # register image for the error message
wn.register_shape("coin.gif") # register image for the coin
wn.register_shape("white_screen.gif") # register white_scrren.gif
wn.register_shape("play_again.gif") # register the image for the play again button
wn.register_shape("pterodactyl2.gif") #register second pterodactyl image 
wn.register_shape("exit_button2.gif") # register exit_button2.gif
wn.register_shape("score.gif") # register shape
wn.register_shape("proceed.gif") # register shape
wn.register_shape("game_over.gif") # register shape
wn.register_shape("space_monster.gif") # register shape
wn.register_shape("proceed_screen.gif") # register shape
wn.register_shape('0.gif') # register shape for score value
wn.register_shape('1.gif') # register shape for score value
wn.register_shape('2.gif') # register shape for score value
wn.register_shape('3.gif') # register shape for score value
wn.register_shape('4.gif') # register shape for score value
wn.register_shape('5.gif') # register shape for score value
wn.register_shape('6.gif') # register shape for score value
wn.register_shape('7.gif') # register shape for score value
wn.register_shape('8.gif') # register shape for score value
wn.register_shape('9.gif') # register shape for score value
wn.register_shape('10.gif') # register shape for score value
wn.register_shape('11.gif') # register shape for score value
wn.register_shape('12.gif') # register shape for score value
wn.register_shape('13.gif') # register shape for score value
wn.register_shape('14.gif') # register shape for score value
wn.register_shape('15.gif') # register shape for score value
wn.register_shape('16.gif') # register shape for score value
wn.register_shape('17.gif') # register shape for score value
wn.register_shape('18.gif') # register shape for score value
wn.register_shape('19.gif') # register shape for score value
wn.register_shape('20.gif') # register shape for score value
wn.register_shape('21.gif') # register shape for score value
wn.register_shape('22.gif') # register shape for score value
wn.register_shape('23.gif') # register shape for score value
wn.register_shape('24.gif') # register shape for score value
wn.register_shape('25.gif') # register shape for score value
wn.register_shape('26.gif') # register shape for score value
wn.register_shape('27.gif') # register shape for score value
wn.register_shape('28.gif') # register shape for score value
wn.register_shape('29.gif') # register shape for score value
wn.register_shape('30.gif') # register shape for score value
wn.register_shape('31.gif') # register shape for score value
wn.register_shape('32.gif') # register shape for score value
wn.register_shape('33.gif') # register shape for score value
wn.register_shape('34.gif') # register shape for score value
wn.register_shape('35.gif') # register shape for score value
wn.register_shape('36.gif') # register shape for score value
wn.register_shape('37.gif') # register shape for score value
wn.register_shape('38.gif') # register shape for score value
wn.register_shape('39.gif') # register shape for score value
wn.register_shape('40.gif') # register shape for score value
wn.register_shape('41.gif') # register shape for score value
wn.register_shape('42.gif') # register shape for score value
wn.register_shape('43.gif') # register shape for score value
wn.register_shape('44.gif') # register shape for score value
wn.register_shape('45.gif') # register shape for score value
wn.register_shape('46.gif') # register shape for score value
wn.register_shape('47.gif') # register shape for score value
wn.register_shape('48.gif') # register shape for score value
wn.register_shape('49.gif') # register shape for score value
wn.register_shape('50.gif') # register shape for score value
wn.register_shape('score_message.gif') # register shape for score message
wn.tracer(0) # set tracer equal to 0 for faster animation updates

# ----------------------------------- Turtle Setup -----------------------------------------
desert_background = turtle.Turtle() # create a turtle for the desert background image
desert_background.pu() # pen up
desert_background.ht() # hide desert_background

pen = turtle.Turtle() # create a pen turtle to write text on the screen 
pen.pu() # pen up
pen.ht() # hide the pen turtle
penstyle_instructions1 = ("Arial", 40) # penstyle for the instructions title
penstyle_instructions2 = ("Arial", 20) # penstyle for the rest of the instructions

pen_coins = turtle.Turtle() # create a pen turtle to write text on the screen 
pen_coins.pu() # pen up
pen_coins.ht() # hide the pen turtle

continue_button = turtle.Turtle() # create a continue button turtle 
continue_button.pu() # pen up
continue_button.goto(-25,-250) # move continue_button to -25, -250
continue_button.shape("continue_button.gif") # set continue_button shape to continue_button.gif
continue_button.ht() # hide continue button

play_button = turtle.Turtle() # create a play button turtle 
play_button.pu() # pen up 
play_button.shape("play_button.gif") # set play button shape to play_again.gif
play_button.goto(-200,-225) # move play button
play_button.pd() # pen down
play_button.ht() # hide play button 

exit_button = turtle.Turtle() # create an exit button turtle 
exit_button.pu() # pen up 
exit_button.shape("exit_button.gif") # set exit button shape to exit_button.gif
exit_button.goto(200,-225) # move exit button
exit_button.ht() # hide exit button

t_rex = turtle.Turtle() # create a t-rex turtle 
t_rex.shape("t-rex.gif") # set t_rex shape to t-rex.gif
t_rex.pu() # pen up 
t_rex.goto(-500, -125) # move the t-rex turtle to -500, -150
t_rex.pd() # pen down
t_rex.ht() # hide t-rex turtle 

error_message = turtle.Turtle() # create a turtle to display the error message 
error_message.pu() # pen up
error_message.goto(400,150) # move error message to 400,150
error_message.shape("error_message.gif") # set error message shape to error_message.gif
error_message.ht() # hide error_message turtle

coin = turtle.Turtle() # create a coin turtle 
coin.ht() # hide coin turtle
coin.shape("coin.gif") # set coin turtle shape to coin.gif
coin.pu() # pen up 
coin.goto(0,-175) # move coin turtle

score_message = turtle.Turtle() # create a turtle to display the score 
score_message.pu() # pen up 
score_message.goto(0,0)
score_message.shape("score_message.gif")
score_message.ht() # hide turtle

score = turtle.Turtle() # create a turtle to display the score 
score.pu() # pen up 
score.goto(50,0)
score.shape("0.gif")
score.ht() # hide turtle

cactus_states = ["cactus.gif", "knocked_cactus.gif"] # create a list of cactus
many_cacti = random.randint(1,2) # generate a random number of cacti
cactus_images = [] # create an empty list to store the cactus images
x_pos = random.randint(-400, 600)
for i in range(many_cacti): # depending on how many cacti were generated
  cactus = turtle.Turtle() # create a cactus turtle 
  cactus.pu() # pen up
  cactus.shape("cactus.gif") # set cactus shape to cactus.gif
  cactus.ht() # hide cactus turtle
  cactus.goto(x_pos, -175) # move cactus turtle
  x_pos += 250 # increase the x position by 250
  cactus_images.append(cactus) # add a cactus turtle to the list of cactus images

many_pterodactyl = random.randint(1,2) # generate a random number of pterodactyls
pterodactyl_images = [] # create an empty list to store the pterodactyl images
x_pos = random.randint(-100, 500)
for i in range(1): # depending on how many pterodactyls were generated
  pterodactyl = turtle.Turtle() # create a pterodactyl turtle
  pterodactyl.pu() # pen up
  pterodactyl.shape("pterodactyl.gif") # set pterodactyl shape to pterodactyl.gif
  pterodactyl.ht() # hide pterodactyl turtle 
  pterodactyl.goto(x_pos, 200) # move pterodactyl to x_pos, 200
  x_pos += 200 # increase the x position by 200
  pterodactyl_images.append(pterodactyl) # add a pterodactyl turtle to the list of pterodactyl images

many_lives = [] # create an empty list to store the lives
lives_x = -550 # starting x value for the lives
for i in range(3): # repeat code three times
  life = turtle.Turtle() # create a life turtle 
  life.ht() # hide life turtle
  life.pu() # pen up 
  life.goto(lives_x, 200) # move life turtle to lives_x, 200
  life.shape("heart.gif") # set the life shape to heart.gif 
  lives_x += 50 # increase the x co-ordinate of the lives by 50
  many_lives.append(life) # add a life to the list of lives

many_coins = [] # create an empty list
coin_number = random.randint(1,3) # generate a random coin number
x_pos = random.randint(-100, 500) # generate a random x position
for i in range(coin_number): # for each coin turtle
  coin = turtle.Turtle() # create a coin turtle 
  coin.pu() # pen up
  coin.shape("coin.gif") # set coin shape to coin.gif
  coin.ht() # hide turtle
  coin.goto(x_pos, -175) # move the coin
  x_pos += 250 # increase x position by 250
  many_coins.append(coin) # add a coin turtle to the list of coin images
  

# ----------------------------------- Global Variables ----------------------------------------
t_rex.direction = "stop" # set the initial direction of the t-rex equal to stop
camera_dx = 0 # set camera offset value equal to 0 
camera_x = 0 # set camera x value equal to 0

#game_over = False # set game_over equal to False
int_lives = 3 # have user start with 3 lives
int_score = 0 # have user start with a score of 0
start_time = time.time() 

# ----------------------------------- Functions -----------------------------------------
def home_screen(): # function to display the home screen
  wn.bgpic("home_screen.gif") # display home_screen
  play_button.st() # show play button
  exit_button.st() # show exit button

def write_instructions(x,y): # create a function to display the game instructions on the screen 
  wn.bgpic("white_screen.gif") # clear window
  wn.update() # update window
  play_button.ht() # hide play button
  exit_button.ht() # hide exit button
  continue_button.st() # show continue button
  pen.goto(0,350) # move the pen to 0,0 
  pen.write("Game Instructions", font = penstyle_instructions1, align = "center") # write the title for the instructions 
  pen.pu() # pen up 
  pen.goto(0,250) # move pen to 0,250
  pen.write("Press the spacebar to jump", font = penstyle_instructions2, align = "center") # write the instructions
  pen.pu() # pen up 
  pen.goto(0,175) # move pen to 0,175
  pen.write("Press the right arrow key to move right", font = penstyle_instructions2, align = "center") # write the instructions
  pen.pu() # pen up 
  pen.goto(0,100) # move pen to 0,100
  pen.write("Avoid hitting the cacti and pterodactyls", font = penstyle_instructions2, align = "center") # write the instructions
  pen.pu() # pen up 
  pen.goto(0,25) # move pen to 0,25
  pen.write("Every time you collect a coin you earn points", font = penstyle_instructions2, align = "center") # write the instructions
  pen.pu() # pen up 
  pen.goto(0,-50) # move pen to 0,-50
  pen.write("Every time you hit an obstacle you lose a life", font = penstyle_instructions2, align = "center") # write the instructions
  pen.pu() # pen up
  pen.goto(0,-125) # move pen to 0,-125
  pen.write("When you run out of lives, the game is over", font = penstyle_instructions2, align = "center") # write the instructions
  pen.pu() # pen up
  pen.goto(0,-200) # move pen to 0,-200
  pen.write("Press the left arrow to move left", font = penstyle_instructions2, align = "center") # write the instructions

def scroll_background(): # function to allow the desert backgrounds to scroll
  global camera_x # set camera_x variable to global 
  global camera_dx # set camera_dx variable to global 
  camera_x += 1 # move the camera sideways  

def move_right(): # function to make the t-rex move right
  t_rex.direction = "right" # set the t-rex's direction equal to right

def move_left(): # function to make the t-rex move left 
  t_rex.direction = "left" # set the t-rex's direction equal to left

def t_rex_direction(): # create a function to change the t-rex's direction
  if t_rex.direction == "right": # check if the t-rex's direction is right
    if t_rex.xcor() <= 600: # keep moving right only if the t-rex's x position is less than or equal to 600 
      int_x = t_rex.xcor() # get the t-rex's current x position
      int_x += 0.5 # add 0.5 to the x co-ordinate to move right 
      t_rex.setx(int_x) # set t_rex position to the x value
  
  if t_rex.direction == "left": # check if the t-rex's direction is left
    if t_rex.xcor() > -600: # if the t-rex's x coordinate is greater than -600
      int_x = t_rex.xcor() # get the t-rex's current x position
      int_x -= 0.5 # subtract 0.5 from the x co-ordinate to move right 
      t_rex.setx(int_x) # set t_rex position to the x value
  
def jump_up(): # function to make the t-rex jump in the air 
  if t_rex.ycor() >= -125 and t_rex.xcor() <= 600: # if the t-rex's x position is greater than or equal to -125
    int_y = t_rex.ycor() # get the t-rex's current y position
    int_y += 100 # add one to make the t-rex jump
    t_rex.sety(int_y) # set the t_rex position to the y value
    int_x = t_rex.xcor() # get the t-rex's current x position
    int_x += 150 # increase the t-rex's x position by 150 units
    t_rex.setx(int_x) # set t_rex position to the x value
    if t_rex.xcor() > 600: # if the t-rex's x coordinate is greater than 600
      t_rex.goto(-500, -125) # move t-rex to -500,-125

def gravity_trex(): # gravity function to make the t_rex come down after jumping
  int_y = t_rex.ycor() # get the t-rex's current y position
  int_y -= 100 # subtract 1 to make the t_rex come down 
  t_rex.sety(int_y) # set the t_rex position to the y value

def gravity_pterodactyl(): # greavity function to make the pterodactyls fall down from the sky
  for pterodactyl in pterodactyl_images: # for each of the pterodactyls in the pterodactyl_images list
    pterodactyl.stamp() # leave a copy of the pterodcatyl behind
    int_y = pterodactyl.ycor() # get the pterodactyls current y position
    int_y -= 1 # subtract 1 to make the pterodactyls come down
    pterodactyl.sety(int_y) # set the pterodactyl's y position to the y value

def move_cacti(): # function to move the cacti across the screen
  global int_lives # set the int_lives variable to global
  for cactus in cactus_images: # for each cactus in the cactus-images list
    cactus.st() # show cactus turtle
    int_x = cactus.xcor() # get the x co-ordinate of the cacti 
    int_x -= 0.3 # subtract 0.3 from the cactus' x co-ordinate
    cactus.setx(int_x) # set the cactus position to the x value
    if int_x <= -600: # check to see if the cacti have reached the far left side of the screen 
      x_pos = random.randint(-400, 600)
      cactus.goto(x_pos, -175) # move the cacti back to the right side of the screen
    if cactus.distance(t_rex) <100: # check to see if the t_rex and any of the cacti are within 100 units
      cactus.shape("knocked_cactus.gif")
      x_pos = random.randint(-400, 600)
      cactus.goto(x_pos, -175) # move the cacti back to the right side of the screen 
      int_lives -= 1 # remove a life
      for i in range(int_lives): # for each life turtle
        many_lives[i].ht() # remove a life turtle from the many_lives list
    if cactus.xcor()<-400: # once the knocked down cactus has reached the left side of the screen
      cactus.shape("cactus.gif") # change the cactus' shape back to cactus.gif
    
def move_pterodactyls(): # function to move the pterodactyls across the screen
  global int_lives # set the int_lives variable to global
  for pterodactyl in pterodactyl_images: # for each pterodactyl in the pterodactyl_images list
    pterodactyl.st() # show pterodactyl turtle 
    int_x = pterodactyl.xcor() # get the x co-ordinate of the pterodactyl 
    int_x -= 0.3 # subtract 0.3 from the pterodactyl's x co-ordinate
    pterodactyl.setx(int_x) # set the pterodactyl's position to the x value 
    if int_x <= -600: # check to see if the pterodactyl have reached the far left side of the screen
      x_pos = random.randint(-100, 500) # set the x_pos to a random value
      pterodactyl.goto(x_pos, 200) # move the pterodactyl to x_pos, 200
    if pterodactyl.distance(t_rex) <100: # check to see if the t_rex and a pterodactyl are within 20 units
      pterodactyl.shape("pterodactyl2.gif") # set the pterodactyl's shape to pterodactyl2.gif
      x_pos = random.randint(-100, 500) # set the x_pos to a random value
      pterodactyl.goto(x_pos, 200) # move the pterodactyl to x_pos, 200
      int_lives -= 1 # remove a life
      for i in range(int_lives): # for each life turtle
        many_lives[i].ht() # remove a life turtle from the many_lives list
    if pterodactyl.ycor() <-200: # if the pterodactyl's y co-ordinate is less than -200
      pterodactyl.shape("pterodactyl.gif") # change the pterodactyl's shape to pterodactyl.gif

score_states = ["1.gif", "2.gif", "3.gif", "4.gif", "5.gif", "6.gif", "7.gif", "8.gif", "9.gif", "10.gif", "11.gif", "12.gif", "13.gif", "14.gif", "15.gif", "16.gif", "17.gif", "18.gif", "19.gif", "20.gif", "21.gif", "22.gif", "23.gif", "24.gif", "25.gif", "26.gif", "27.gif", "28.gif", "29.gif", "30.gif", "31.gif", "32.gif", "33.gif", "34.gif", "35.gif", "36.gif", "37.gif", "38.gif", "39.gif", "40.gif", "41.gif", "42.gif", "43.gif", "44.gif", "45.gif", "46.gif", "47.gif", "48.gif", "49.gif", "50.gif"] # create a list of images for the score values
def collect_coins(): # function to execute when player collects a coin 
  global int_score # set the int_score variable to global
  for coin in many_coins: # for each coin turtle in the many_coins list
    coin.st() # show cactus turtle
    int_x = coin.xcor() # get the x co-ordinate of the cacti 
    int_x -= 0.3 # subtract 0.3 from the cactus' x co-ordinate
    coin.setx(int_x) # set the cactus position to the x value
    if int_x <= -600: # check to see if the cacti have reached the far left side of the screen 
      x_pos = random.randint(-400, 600) # generate a random x-position
      coin.goto(x_pos, -175) # move the cacti back to the right side of the screen
    if coin.distance(t_rex) <100: # if the t-rex is within 100 units of a coin
      x_pos = random.randint(-400, 600) # generate a random x-position
      coin.goto(x_pos, -175) # move the cacti back to the right side of the screen
      int_score += 1 # add 1 to the int_score variable
      for i in range(int_score):
        score.shape(score_states[i]) # change the score shape to the next image in the score_states list

def stop_moving(): # function to make the t-rex stop moving
  t_rex.direction = "stop" # set the t-rex direction to stop

def run_game(x,y): # function to execute when continue button is clicked
  wn.update() # update window
  wn.clear() # clear window
  wn.tracer(0) # set tracer equal to 0
  wn.setup(width = 1300, height = 550) # setup a window with width and height 
  wn.listen() # listen for keys pressed 
  wn.onkeypress(move_right, "Right") # call move_right function if right arrow key is pressed
  wn.onkeyrelease(stop_moving, "Right") # call stop_moving function if the right arrow key is released
  wn.onkeypress(jump_up, "space") # call jump_up function if space bar is pressed
  wn.onkeyrelease(gravity_trex, "space") # call gravity function to make the t-rex come down if space bar is released
  wn.onkeypress(move_left, "Left") # call move_left function is left arrow is pressed
  wn.onkeyrelease(stop_moving, "Left") # call stop_moving function if left arrow is released
  while int_lives > 0: # while the play has not run out of lives
    global camera_x # set camera_x variable to global 
    global camera_dx # set camera_dx variable to global 
    scroll_background() # call scroll_background function
    t_rex_direction() # call t_rex_direction
    move_cacti() # call move_cacti function
    move_pterodactyls() # call move_pterodactyls function
    collect_coins() # call collect_coins function
    camera_x += camera_dx # move camera sideways
    camera_x %= 950 # reset the background using modulus 
    desert_background.goto(camera_x-950, 0) # move the background to camera_x-950, 0
    desert_background.shape("desert_bg.gif") # set the background shape to desert_bg.gif
    desert_background.stamp() # leave a copy of the background behind
    t_rex.st() # show t-rex turtle
    t_rex.stamp() # stamp t-rex turtle
    error_message.stamp() # leave a copy of the error message behind
    for cactus in cactus_images: # for each cactus in the cactus_images list
      cactus.stamp() # leave a copy of each cactus behind
    for i in range(int_lives): # for each life turtle
      many_lives[i].stamp() # remove a life turtle from the many_lives list
    for coin in many_coins: # for each coin turtle in the many_coins list
      coin.stamp() # leave a copy of the coin behind 
    time_elapsed() # call time_elapsed function
    score.stamp() # leave a copy of the score behind
    score_message.stamp() # leave a copy of the score message behind

    desert_background.goto(camera_x,0) # move the background to camera_x, 0 
    desert_background.shape("desert_bg2.gif") # set the background shape to desert_bg.gif
    desert_background.stamp() # leave a copy of the background behind
    t_rex.st() # show t-rex turtle
    t_rex.stamp() # stamp t-rex turtle
    error_message.stamp() # leave a copy of the error message behind
    for cactus in cactus_images: # for each cactus in the cactus_images list
      cactus.stamp() # leave a copy of each cactus behind
    for i in range(int_lives): # for each life turtle
      many_lives[i].stamp() # remove a life turtle from the many_lives list
    for coin in many_coins: # for each coin turtle in the many_coins list
      coin.stamp() # leave a copy of the coin behind 
    time_elapsed() # call time_elapsed function
    score.stamp() # leave a copy of the score behind
    score_message.stamp() # leave a copy of the score message behind
   
    wn.update() # update window
    desert_background.clear() # clear old copies of the background
    t_rex.clear() # clear old copies of the t-rex turtle
    #extra_life.clear() # clear old copies of the extra life turtle
    error_message.clear() # clear old copies of the error message
    for cactus in cactus_images: # for each cactus in the cactus_images list
      cactus.clear() # remove old copies of the cactus turtles
    for i in range(int_lives):  
      many_lives[i].clear() # remove a life turtle from the many_lives list
    for pterodactyl in pterodactyl_images: # for each pterodactyl in the pterodactyl_images list
      pterodactyl.clear() # clear old copies of the pterodactyls
    for coin in many_coins: # for each coin turtle in the many_coins list
      coin.clear() # clear old copies of the coin turtles
    score.clear() # clear old copies of the score
    score_message.clear() # clear old copies of the score message
    
    if int_lives <= 0: # if the player runs out of lives
      global game_over # set game_over to global
      game_over = True # set game_over variable equal to true
      end_game() # call end_game function to end the game 

def end_game(): # function to execute when player runs out of lives
  wn.update() # update window
  wn.clear() # clear window
  wn.setup(width = 1300, height = 975) # setup a window with width and height 
  wn.bgcolor("black") # set window background color to black
  pen.clear() # clear pen
  pen_coins.pu() # pen up
  pen_coins.color("white") # set the text color ro white
  pen_coins.goto(0,100) # move pen_coins turtle
  pen_coins.write("coins collected:" + str(int_score)) # print the player's score 
  gameover_message = turtle.Turtle() # create a turtle to display the game over message
  gameover_message.pu() # pen up
  gameover_message.goto(0,100) # move game over message
  gameover_message.shape("game_over.gif") # set game over message shape to game_over.gif
  gameover_message.stamp() # leave a copy of the game over message behind
  space_monster = turtle.Turtle() # create a space monster turtle
  space_monster.pu() # pen up
  space_monster.goto(-400,50) # move the space monster
  space_monster.shape("space_monster.gif") # set space monster shape to space_monster.gif
  space_monster2 = turtle.Turtle() # create a space monster turtle
  space_monster2.pu() # pen up
  space_monster2.goto(400,50) # move space monster 2
  space_monster2.shape("space_monster.gif") # set space monster 2 shape to space_monster.gif
  play_again = turtle.Turtle() # create a play again button turtle
  play_again.pu() # pen up
  play_again.goto(-350,-250) # move play again turtle
  play_again.shape("play_again.gif") # set play again shape to play_again.gif
  play_again.onclick(reset_game) # if play again button is clicked, call run_game function
  exit_button2 = turtle.Turtle() # create an exit button turtle 
  exit_button2.pu() # pen up 
  exit_button2.shape("exit_button2.gif") # set exit button shape to exit_button.gif
  exit_button2.goto(250,-325) # move exit button
  exit_button2.onclick(exit_game) # call exit_game function if exit_button is clicked

def reset_game(x,y): # create a fucntion to reset the game
  wn.update() # update window
  wn.clear() # clear window
  global int_lives # set int_lives to global
  int_lives = 3 # reset int_lives equal to 3
  global int_score # set int_score variable to global
  int_score = 0 # reset int_score variable to 0
  wn.bgpic("proceed_screen.gif") # set the window background pic to proceed_screen.gif
  play_game = turtle.Turtle() # create a play game turtle
  play_game.pu() # pen up
  play_game.goto(0,0) # move play game turtle to 0,0
  play_game.shape("proceed.gif") # set the play game turtle shape to proceed.gif
  score.shape("0.gif") # set the score shape to 0.gif
  play_game.onclick(run_game) # call run_game fucntion when play_game turtle is clicked
  

def exit_game(x,y): # function to execute when exit button is clicked
  wn.clear() # clear window
  turtle.bye() # end program

def time_elapsed(): # create a time elasped function to make objects appear at random times
  global start_time # set the start_time variable to global
  current_time = time.time() # calculate the current time
  game_time = round(current_time - start_time) # calculate the game time 
  if game_time%5 == 0: # if the game_time value is a multiple of 5
    for pterodactyl in pterodactyl_images: # for each pterodactyl in the pterodactyl_images list
      pterodactyl.stamp() # leave a copy of each pterodactyl behind
      gravity_pterodactyl() # call gravity_pterodactyl function

# ----------------------------------- Main Program -----------------------------------------
global home_menu # set home_menu variable to global
home_menu = False # set home_menu equal to False
global game_over # set game_over variable to global
game_over = False # set game_over variable to false
while home_menu == False: # while the home menu is still being displayed
  wn.tracer(1) # set tracer equal to 1
  home_screen() # call home_screen function
  play_button.onclick(write_instructions) # execute write_instructions function when play_button turtle is clicked
  exit_button.onclick(exit_game) # execute end_game function when exit_button turtle is clicked
  while game_over == False: # while the game is not over
    home_menu = True # while home_menu is equal to true
    continue_button.onclick(run_game) # call run_game function when continue button is clicked